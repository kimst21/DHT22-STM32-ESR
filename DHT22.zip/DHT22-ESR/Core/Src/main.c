/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fonts.h"   // OLED 디스플레이에 사용되는 폰트 라이브러리
#include "ssd1306.h" // SSD1306 OLED 디스플레이 제어 라이브러리
#include "stdio.h"   // 문자열 처리 및 출력 형식 지정 라이브러리
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define DHT22_PORT GPIOC  // DHT22 센서 데이터 핀이 연결된 GPIO 포트
#define DHT22_PIN GPIO_PIN_13  // DHT22 센서 데이터 핀이 연결된 핀 번호
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
uint8_t hum1, hum2, tempC1, tempC2, SUM, CHECK;  // 습도 및 온도 데이터 저장용 변수
uint32_t pMillis, cMillis;  // 시간 계산용 변수
float temp_Celsius = 0, temp_Fahrenheit = 0, Humidity = 0;  // 계산된 온도 및 습도 값
uint8_t hum_integral, hum_decimal, tempC_integral, tempC_decimal, tempF_integral, tempF_decimal;  // 출력용 데이터 정수/소수 분리 변수
char string[15];  // OLED 디스플레이 출력용 문자열 버퍼
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// 마이크로초 단위 지연 함수
// TIM3 타이머를 사용하여 정확한 시간 지연을 구현
void microDelay(uint16_t delay) {
  __HAL_TIM_SET_COUNTER(&htim3, 0);  // 타이머 카운터를 0으로 초기화
  while (__HAL_TIM_GET_COUNTER(&htim3) < delay);  // 카운터가 지정된 시간에 도달할 때까지 대기
}

// DHT22 초기화 및 응답 확인 함수
uint8_t DHT22_Start(void) {
  uint8_t Response = 0;  // 센서의 응답 상태 저장
  GPIO_InitTypeDef GPIO_InitStructPrivate = {0};

  // GPIO 핀을 출력 모드로 설정 후 신호 전송
  GPIO_InitStructPrivate.Pin = DHT22_PIN;
  GPIO_InitStructPrivate.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStructPrivate.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStructPrivate.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DHT22_PORT, &GPIO_InitStructPrivate);

  HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, 0);  // 센서에 LOW 신호 전송 (시작 신호)
  microDelay(1300);  // 1.3ms 대기

  HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, 1);  // HIGH 신호 전환
  microDelay(30);  // 30us 대기

  // GPIO 핀을 입력 모드로 전환
  GPIO_InitStructPrivate.Mode = GPIO_MODE_INPUT;
  GPIO_InitStructPrivate.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DHT22_PORT, &GPIO_InitStructPrivate);
  microDelay(40);  // 40us 대기

  // 센서 응답 확인
  if (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {  // LOW 상태 확인
    microDelay(80);  // 80us 대기
    if (HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) Response = 1;  // HIGH 상태 확인 시 응답 성공
  }

  // 센서의 신호가 끝날 때까지 대기
  pMillis = HAL_GetTick();
  cMillis = HAL_GetTick();
  while ((HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) && (pMillis + 2 > cMillis)) {
    cMillis = HAL_GetTick();
  }

  return Response;  // 응답 상태 반환
}

// DHT22에서 1바이트 데이터 읽기
uint8_t DHT22_Read(void) {
  uint8_t x, y = 0;

  for (x = 0; x < 8; x++) {
    pMillis = HAL_GetTick();
    cMillis = HAL_GetTick();

    // LOW 상태가 끝날 때까지 대기
    while (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) && (pMillis + 2 > cMillis)) {
      cMillis = HAL_GetTick();
    }

    microDelay(40);  // 40us 대기

    // 데이터 비트 읽기 (HIGH 상태인지 확인)
    if (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {
      y &= ~(1 << (7 - x));  // LOW 상태일 경우 해당 비트를 0으로 설정
    } else {
      y |= (1 << (7 - x));  // HIGH 상태일 경우 해당 비트를 1로 설정
    }

    // HIGH 상태가 끝날 때까지 대기
    pMillis = HAL_GetTick();
    cMillis = HAL_GetTick();
    while ((HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) && (pMillis + 2 > cMillis)) {
      cMillis = HAL_GetTick();
    }
  }

  return y;  // 읽은 데이터 반환
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {

  /* USER CODE BEGIN 1 */
  // 메인 함수 초기 설정
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();  // HAL 라이브러리 초기화

  /* USER CODE BEGIN Init */
  // 사용자 정의 초기화 코드
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();  // 시스템 클럭 설정

  /* USER CODE BEGIN SysInit */
  // 시스템 초기화 추가 설정
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();  // GPIO 초기화
  MX_I2C3_Init();  // I2C 초기화
  MX_TIM3_Init();  // TIM3 초기화
  /* USER CODE BEGIN 2 */
  // 타이머 시작 및 디스플레이 초기화
  HAL_TIM_Base_Start(&htim3);
  SSD1306_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1) {
    // 무한 루프: DHT22 데이터 읽기 및 출력 반복
    if (DHT22_Start()) {
      hum1 = DHT22_Read();  // 습도 정수부 읽기
      hum2 = DHT22_Read();  // 습도 소수부 읽기
      tempC1 = DHT22_Read();  // 온도 정수부 읽기
      tempC2 = DHT22_Read();  // 온도 소수부 읽기
      SUM = DHT22_Read();  // 체크섬 읽기

      CHECK = hum1 + hum2 + tempC1 + tempC2;  // 데이터 합산 체크
      if (CHECK == SUM) {  // 데이터 유효성 검증
        // 온도 및 습도 계산
        if (tempC1 > 127) {
          temp_Celsius = (float)tempC2 / 10 * (-1);
        } else {
          temp_Celsius = (float)((tempC1 << 8) | tempC2) / 10;
        }
        temp_Fahrenheit = temp_Celsius * 9 / 5 + 32;
        Humidity = (float)((hum1 << 8) | hum2) / 10;

        // OLED 디스플레이에 데이터 출력
        SSD1306_GotoXY(0, 0);
        sprintf(string, "H: %.1f %%", Humidity);
        SSD1306_Puts(string, &Font_11x18, 1);

        SSD1306_GotoXY(0, 20);
        sprintf(string, "C: %.1f C", temp_Celsius);
        SSD1306_Puts(string, &Font_11x18, 1);

        SSD1306_GotoXY(0, 40);
        sprintf(string, "F: %.1f F", temp_Fahrenheit);
        SSD1306_Puts(string, &Font_11x18, 1);

        SSD1306_UpdateScreen();  // 화면 갱신
      }
    }
    HAL_Delay(1000);  // 1초 대기 후 다음 데이터 읽기
  }
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
