/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - STM32 마이크로컨트롤러와 DHT22 센서를 사용하여 온도와 습도를 측정하고 SSD1306 디스플레이에 출력하는 프로그램입니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 시스템 초기화 관련 헤더
#include "i2c.h"         // I2C 초기화 및 제어 관련 헤더
#include "tim.h"         // 타이머 설정 및 초기화 관련 헤더
#include "gpio.h"        // GPIO 초기화 관련 헤더

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fonts.h"       // SSD1306 디스플레이용 글꼴
#include "ssd1306.h"     // SSD1306 디스플레이 제어 라이브러리
#include "stdio.h"       // 문자열 및 데이터 처리 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
#define DHT22_PORT GPIOC                // DHT22 센서 연결 GPIO 포트
#define DHT22_PIN GPIO_PIN_13           // DHT22 센서 연결 GPIO 핀
uint8_t hum1, hum2, tempC1, tempC2, SUM, CHECK;
uint32_t pMillis, cMillis;
float temp_Celsius = 0;
float temp_Fahrenheit = 0;
float Humidity = 0;
uint8_t hum_integral, hum_decimal, tempC_integral, tempC_decimal, tempF_integral, tempF_decimal;
char strCopy[30];                      // 디스플레이용 문자열 버퍼
/* USER CODE END PV */

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void);         // 시스템 클럭 설정 함수

/* USER CODE BEGIN 0 */

/**
  * @brief  마이크로초 단위 지연 함수
  * @param  delay : 지연 시간 (마이크로초 단위)
  */
void microDelay (uint16_t delay)
{
  __HAL_TIM_SET_COUNTER(&htim3, 0);
  while (__HAL_TIM_GET_COUNTER(&htim3) < delay);
}

/**
  * @brief  DHT22 센서 시작 신호 전송 및 응답 확인
  * @retval uint8_t : 센서 응답 여부 (1: 성공, 0: 실패)
  */
uint8_t DHT22_Start (void)
{
  uint8_t Response = 0;
  GPIO_InitTypeDef GPIO_InitStructPrivate = {0};

  // DHT22 핀을 출력 모드로 설정
  GPIO_InitStructPrivate.Pin = DHT22_PIN;
  GPIO_InitStructPrivate.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStructPrivate.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStructPrivate.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DHT22_PORT, &GPIO_InitStructPrivate);

  // 시작 신호 전송 (LOW)
  HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, 0);
  microDelay(1300);  // 1.3ms 대기

  // 핀을 HIGH로 설정
  HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, 1);
  microDelay(30);    // 30us 대기

  // 핀을 입력 모드로 변경하여 응답 대기
  GPIO_InitStructPrivate.Mode = GPIO_MODE_INPUT;
  GPIO_InitStructPrivate.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DHT22_PORT, &GPIO_InitStructPrivate);

  // DHT22 응답 확인
  microDelay(40);
  if (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) // LOW 응답 확인
  {
    microDelay(80);
    if (HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) // HIGH 응답 확인
      Response = 1;
  }
  return Response; // 응답 상태 반환
}

/**
  * @brief  DHT22 센서에서 데이터 읽기
  * @retval uint8_t : 읽은 데이터 값 (8비트)
  */
uint8_t DHT22_Read (void)
{
  uint8_t x, y = 0;
  for (x = 0; x < 8; x++)
  {
    while (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))); // LOW 대기
    microDelay(40); // 신호 길이에 따라 데이터 확인
    if (HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) // HIGH인지 확인
      y |= (1 << (7 - x));
    while (HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)); // LOW로 대기
  }
  return y; // 읽은 데이터 반환
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 사용자 정의 초기화 전 변수 설정 가능
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정

  MX_GPIO_Init();                  // GPIO 초기화
  MX_I2C3_Init();                  // I2C3 초기화 (SSD1306 통신용)
  MX_TIM3_Init();                  // TIM3 초기화 (DHT22 지연시간 처리용)

  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim3);      // TIM3 시작
  SSD1306_Init();                  // SSD1306 OLED 디스플레이 초기화
  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
    /* USER CODE BEGIN WHILE */
    if (DHT22_Start()) // DHT22 데이터 요청
    {
      hum1 = DHT22_Read(); // 습도 데이터 상위 바이트
      hum2 = DHT22_Read(); // 습도 데이터 하위 바이트
      tempC1 = DHT22_Read(); // 온도 데이터 상위 바이트
      tempC2 = DHT22_Read(); // 온도 데이터 하위 바이트
      SUM = DHT22_Read();    // 체크섬 데이터

      // 데이터 유효성 검사
      CHECK = hum1 + hum2 + tempC1 + tempC2;
      if (CHECK == SUM)
      {
        // 온도와 습도 계산
        temp_Celsius = ((tempC1 & 0x7F) << 8 | tempC2) / 10.0; // 섭씨
        if (tempC1 & 0x80) temp_Celsius *= -1;                 // 음수 처리
        temp_Fahrenheit = temp_Celsius * 9 / 5 + 32;           // 화씨 변환
        Humidity = ((hum1 << 8) | hum2) / 10.0;                // 습도

        // SSD1306 디스플레이에 출력
        SSD1306_Clear();
        sprintf(strCopy, "H: %.1f %%", Humidity);
        SSD1306_GotoXY(0, 0);
        SSD1306_Puts(strCopy, &Font_11x18, 1);

        sprintf(strCopy, "T: %.1f C", temp_Celsius);
        SSD1306_GotoXY(0, 20);
        SSD1306_Puts(strCopy, &Font_11x18, 1);

        sprintf(strCopy, "T: %.1f F", temp_Fahrenheit);
        SSD1306_GotoXY(0, 40);
        SSD1306_Puts(strCopy, &Font_11x18, 1);

        SSD1306_UpdateScreen();
      }
    }
    HAL_Delay(1000); // 1초 대기
    /* USER CODE END WHILE */
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
